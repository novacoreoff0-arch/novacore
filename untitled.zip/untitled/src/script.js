/* ============================================================
   STATE
============================================================ */
const state = {
  user: { name:'', email:'', provider:'', initials:'N', isAdmin:false, isDeveloper:false, id:null },
  activeTab: 'home',
  balance: { available: 0, pending: 0 },
  stats: { totalSales: 0, totalPurchases: 0, totalEarned: 0 },
  monthly: [ {m:'Feb',v:0},{m:'Mar',v:0},{m:'Apr',v:0},{m:'May',v:0},{m:'Jun',v:0},{m:'Jul',v:0} ],
  currentPlan: 'basic',
  methods: {
    applepay: { connected:false, label:'' },
    cashapp: { connected:false, label:'' },
    card: { connected:false, label:'' },
    bank: { connected:false, label:'' }
  },
  transactions: [],
  offers: [],
  adminSearchQuery: '',
  adminStatusFilter: 'all',
  notifPrefs: { coupons: true, news: true },
  announcements: [],   // developer broadcasts — land in every account's Inbox
  conversations: {}    // per-item chat threads, keyed by "<itemId>::<sellerName>"
};

const CATS = [
  { id:'home', label:'Home' },
  { id:'inbox', label:'Inbox' },
  { id:'messages', label:'Messages' },
  { id:'games', label:'Games' },
  { id:'shoes', label:'Shoes' },
  { id:'clothing', label:'Clothing' },
  { id:'jewelry', label:'Jewelry' },
  { id:'electronics', label:'Electronics' },
  { id:'furniture', label:'Furniture' },
  { id:'sales', label:'My Sales' },
  { id:'payments', label:'Payments' },
];

const CAT_EMOJI = { games:'🎮', shoes:'👟', clothing:'🧥', jewelry:'💍', electronics:'📱', furniture:'🛋️' };

const CAT_GRADIENT = {
  games:'linear-gradient(135deg,#312a5e,#1c2540)',
  shoes:'linear-gradient(135deg,#2e2440,#241c38)',
  clothing:'linear-gradient(135deg,#22304a,#1a2338)',
  jewelry:'linear-gradient(135deg,#3a2f1c,#241d14)',
  electronics:'linear-gradient(135deg,#1c3244,#141f2e)',
  furniture:'linear-gradient(135deg,#2a2418,#1e1c14)',
};

// tint used for each category's icon stroke/fill
const CAT_TINT = { games:'#b7a9ff', shoes:'#e0b8ff', clothing:'#9fc4ff', jewelry:'#f3d48a', electronics:'#8fe3ef', furniture:'#d9b98a' };

// hand-drawn line-icon per category (crisper and more "designed" than emoji)
const CAT_ICON = {
  games: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.games}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="17" width="36" height="18" rx="8"/><path d="M16 23v6M13 26h6"/><circle cx="31" cy="24" r="1.6" fill="${CAT_TINT.games}" stroke="none"/><circle cx="35.5" cy="28" r="1.6" fill="${CAT_TINT.games}" stroke="none"/></svg>`,
  shoes: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.shoes}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 33c0-5 3-7 7-9.5C17 21 19 17 20 13c2 2 3 5 7 6.5 5 1.8 15 2 15 9.5 0 2.5-1.5 4-4 4H9c-2 0-3-1.5-3-3z"/><path d="M20 13v7M27 20l4 4"/></svg>`,
  clothing: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.clothing}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8l6 4 6-4 8 6-5 6-3-2v20H16V18l-3 2-5-6z"/></svg>`,
  jewelry: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.jewelry}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 16h22l6 8-17 16L7 24z"/><path d="M13 16l6 8-5 0M35 16l-6 8 5 0M19 24l5 16 5-16M13 16h22"/></svg>`,
  electronics: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.electronics}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="10" y="8" width="28" height="32" rx="4"/><path d="M18 8V5h12v3M20 34h8"/><rect x="16" y="14" width="16" height="14" rx="2"/></svg>`,
  furniture: `<svg viewBox="0 0 48 48" fill="none" stroke="${CAT_TINT.furniture}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 24v-6a4 4 0 014-4h20a4 4 0 014 4v6"/><path d="M8 24h32v9a2 2 0 01-2 2H10a2 2 0 01-2-2v-9z"/><path d="M11 35v-3M37 35v-3M8 24v0"/><path d="M8 24a3 3 0 000 6M40 24a3 3 0 010 6"/></svg>`,
};

function catIcon(cat, size){
  size = size || 24;
  return `<div class="cat-ic" style="background:${CAT_GRADIENT[cat]}; width:${size}px; height:${size}px;">${CAT_ICON[cat] || ''}</div>`;
}

/* ============================================================
   PRICE FILTER (category & search pages)
============================================================ */
const PRICE_PRESETS = [
  { min:0,   max:10,   label:'$0 - $10' },
  { min:10,  max:50,   label:'$10 - $50' },
  { min:50,  max:150,  label:'$50 - $150' },
  { min:150, max:300,  label:'$150 - $300' },
  { min:300, max:null, label:'$300+' },
];

state.priceFilter = { min:null, max:null };

function isPriceFilterActive(){
  return state.priceFilter.min !== null || state.priceFilter.max !== null;
}

function isActivePricePreset(p){
  return state.priceFilter.min === p.min && state.priceFilter.max === p.max;
}

function applyPriceFilter(items){
  if(!isPriceFilterActive()) return items;
  return items.filter(i => {
    if(state.priceFilter.min !== null && i.price < state.priceFilter.min) return false;
    if(state.priceFilter.max !== null && i.price > state.priceFilter.max) return false;
    return true;
  });
}

function togglePriceDropdown(){
  document.getElementById('priceDropdown').classList.toggle('hidden');
}

function applyPricePreset(min, max){
  state.priceFilter = { min, max };
  document.getElementById('priceDropdown').classList.add('hidden');
  showPage(state.activeTab);
}

function applyCustomPriceRange(){
  const from = document.getElementById('priceFromInput').value;
  const to = document.getElementById('priceToInput').value;
  state.priceFilter = { min: from !== '' ? Number(from) : null, max: to !== '' ? Number(to) : null };
  document.getElementById('priceDropdown').classList.add('hidden');
  showPage(state.activeTab);
}

function clearPriceFilter(){
  state.priceFilter = { min:null, max:null };
  showPage(state.activeTab);
}

function renderPriceFilterBar(){
  const active = isPriceFilterActive();
  const rangeLabel = active ? `$${state.priceFilter.min ?? 0}${state.priceFilter.max!==null ? '–$'+state.priceFilter.max : '+'}` : '';
  return `
  <div class="filter-bar">
    <div class="filter-dropdown-wrap">
      <button class="filter-btn ${active?'active':''}" onclick="event.stopPropagation(); togglePriceDropdown();">
        Price${active ? `<span class="filter-active-range">${rangeLabel}</span>` : ''}
        <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <div class="filter-dropdown hidden" id="priceDropdown">
        <div class="filter-range-inputs">
          <div class="filter-range-field"><span>$</span><input type="number" id="priceFromInput" placeholder="From" value="${state.priceFilter.min ?? ''}"></div>
          <span class="filter-range-dash">–</span>
          <div class="filter-range-field"><span>$</span><input type="number" id="priceToInput" placeholder="To" value="${state.priceFilter.max ?? ''}"></div>
          <button class="filter-apply-btn" onclick="applyCustomPriceRange()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          </button>
        </div>
        <div class="filter-preset-list">
          ${PRICE_PRESETS.map(p => `<button class="filter-preset-row ${isActivePricePreset(p)?'active':''}" onclick="applyPricePreset(${p.min}, ${p.max===null?'null':p.max})">${p.label}</button>`).join('')}
        </div>
      </div>
    </div>
    ${active ? `<button class="filter-clear-link" onclick="clearPriceFilter()">Clear filters</button>` : ''}
  </div>`;
}

document.addEventListener('click', (e)=>{
  if(!e.target.closest('.filter-dropdown-wrap')) document.getElementById('priceDropdown')?.classList.add('hidden');
});

// Intentionally empty — no seeded/placeholder products. Every category tab stays fully
// functional; listings only appear once real users publish them via "List an item".
const LISTINGS = [];

/* ============================================================
   INBOX: coupons, real holiday detection, developer announcements
============================================================ */
const BASE_COUPONS = [
  { code:'WELCOME10', icon:'🎉', title:'Welcome to NovaCore', desc:"Get 10% off your seller fee on your first sale — it's on us." },
  { code:'LISTMORE5', icon:'📦', title:'List 3, save on fees', desc:'Publish three listings this month and your next sale fee drops by 5%.' },
];

// Real holiday detection off the actual system clock — not hardcoded to any one date.
const HOLIDAYS = [
  { month:1, day:1, name:"New Year's Day", icon:'🎆' },
  { month:2, day:14, name:"Valentine's Day", icon:'💘' },
  { month:7, day:4, name:'Independence Day', icon:'🎆' },
  { month:10, day:31, name:'Halloween', icon:'🎃' },
  { month:11, day:27, name:'Thanksgiving', icon:'🦃' },
  { month:12, day:25, name:'Christmas', icon:'🎄' },
  { month:12, day:31, name:"New Year's Eve", icon:'🎊' },
];

function getUpcomingHoliday(windowDays){
  windowDays = windowDays || 21;
  const now = new Date();
  let nearest = null, nearestDiff = Infinity;
  HOLIDAYS.forEach(h => {
    [now.getFullYear(), now.getFullYear()+1].forEach(y => {
      const d = new Date(y, h.month-1, h.day);
      const diffDays = Math.floor((d - now) / 86400000);
      if(diffDays >= -1 && diffDays <= windowDays && diffDays < nearestDiff){
        nearestDiff = diffDays; nearest = h;
      }
    });
  });
  return nearest;
}

function timeAgo(ts){
  const mins = Math.floor((Date.now() - ts) / 60000);
  if(mins < 1) return 'Just now';
  if(mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins/60);
  if(hrs < 24) return hrs + 'h ago';
  return Math.floor(hrs/24) + 'd ago';
}

function getInboxItems(){
  const items = [];
  items.push({ id:'sys-welcome', type:'system', icon:'👋', title:'Welcome to NovaCore', body:"Browse listings, list your own items, or ask Nova AI for help anytime — glad you're here.", time:'Just now' });

  const ownRecord = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(ownRecord && ownRecord.status === 'warned' && ownRecord.warnings > 0){
    items.push({ id:'sys-warned-'+ownRecord.warnings, type:'system', icon:'⚠️', title:'You have an active warning on your account', body:`Your account received ${ownRecord.warnings > 1 ? ownRecord.warnings+' warnings' : 'a warning'} for a Community Guidelines issue. Further warnings can lead to a suspension or ban — worth a re-read of the guidelines if you're unsure why.`, time:'Active' });
  }

  BASE_COUPONS.forEach(c => items.push({ id:'coupon-'+c.code, type:'coupon', icon:c.icon, title:c.title, body:c.desc, code:c.code, time:'This week' }));

  const holiday = getUpcomingHoliday();
  if(holiday){
    const code = 'HOLIDAY' + holiday.name.replace(/[^A-Za-z]/g,'').toUpperCase().slice(0,10);
    items.push({ id:'coupon-holiday-'+code, type:'coupon', icon:holiday.icon, title:`${holiday.name} sale`, body:`To celebrate ${holiday.name}, take an extra discount on your seller fee this week.`, code, time:'Limited time' });
  }

  state.announcements.slice().reverse().forEach(a => {
    items.push({ id:'ann-'+a.id, type:'announcement', icon:'📣', title:a.title, body:a.body, time:timeAgo(a.at) });
  });

  return items;
}

function getUnreadInboxCount(record){
  if(!record) return 0;
  const seen = record.inboxSeenIds || [];
  return getInboxItems().filter(it => {
    if(seen.includes(it.id)) return false;
    return it.type === 'coupon' ? state.notifPrefs.coupons : state.notifPrefs.news;
  }).length;
}

/* ============================================================
   ADMIN / USER DIRECTORY
============================================================ */
const ADMIN_EMAIL = 'novacoreoff0@gmail.com';
// NOTE: this is a front-end-only prototype with no server, so this "password" is just a
// UI gate stored in plain JS — anyone who opens dev tools can read it. It is NOT real
// account security. A real deployment would check credentials against a backend/auth
// provider instead of a string sitting in the client bundle.
const ADMIN_PASSWORD = 'novacore.novacore005';
const FEE_RATES = { basic:0.08, pro:0.05, business:0.03 };

state.users = [
  { id:214009, name:'Marcus D.',  email:'marcus.d@example.com',  role:'user', status:'active',    warnings:0, suspendDays:null, joined:'Mar 2025' },
  { id:358821, name:'Omar F.',    email:'omar.f@example.com',    role:'user', status:'active',    warnings:0, suspendDays:null, joined:'Jan 2025' },
  { id:472290, name:'Grace H.',   email:'grace.h@example.com',   role:'user', status:'active',    warnings:0, suspendDays:null, joined:'Nov 2024' },
  { id:519644, name:'Talia R.',   email:'talia.r@example.com',   role:'user', status:'warned',    warnings:1, suspendDays:null, joined:'Jun 2024' },
  { id:630187, name:'Victor A.',  email:'victor.a@example.com',  role:'user', status:'active',    warnings:0, suspendDays:null, joined:'Feb 2025' },
  { id:725533, name:'Priya N.',   email:'priya.n@example.com',   role:'user', status:'suspended', warnings:2, suspendDays:5,    joined:'Sep 2024' },
  { id:841076, name:'Devon K.',   email:'devon.k@example.com',   role:'user', status:'active',    warnings:0, suspendDays:null, joined:'Apr 2025' },
];

/* ============================================================
   PERSISTENCE — without this, everything (listings, bans, messages,
   coupons claimed) vanished on every page refresh. Saves to this
   browser's localStorage only; there's still no real server, so
   nothing syncs across different browsers or devices.
============================================================ */
const STORAGE_KEY = 'novacore_prototype_state_v1';

function saveToStorage(){
  try{
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      listings: LISTINGS,
      users: state.users,
      announcements: state.announcements,
      conversations: state.conversations,
      notifPrefs: state.notifPrefs
    }));
  }catch(e){ /* storage unavailable (private browsing, quota, etc.) — fail silently */ }
}

function loadFromStorage(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return;
    const data = JSON.parse(raw);
    if(Array.isArray(data.listings)){ LISTINGS.length = 0; data.listings.forEach(l => LISTINGS.push(l)); }
    if(Array.isArray(data.users) && data.users.length){ state.users = data.users; }
    if(Array.isArray(data.announcements)){ state.announcements = data.announcements; }
    if(data.conversations && typeof data.conversations === 'object'){ state.conversations = data.conversations; }
    if(data.notifPrefs){ Object.assign(state.notifPrefs, data.notifPrefs); }
  }catch(e){ /* corrupted or unavailable storage — just start fresh */ }
}

function genUniqueId(){
  let id;
  do{ id = Math.floor(100000 + Math.random()*900000); } while(state.users.some(u=>u.id===id));
  return id;
}
function findUser(id){ return state.users.find(u=>u.id===Number(id)); }

let pendingProvider = null;
let currentItemId = null;
let pendingAdminEmail = null; // holds the email while the dev-password step is showing
let pendingVerificationCode = null; // freshly generated per sign-in attempt, never shared between users

function isWorkingEmailFormat(email){
  // NovaCore only offers Google and Apple sign-in, so the manual email field is held to the
  // same standard: a properly formatted Gmail or iCloud address. This is a format check only —
  // without a real mail server, this preview has no way to confirm the inbox actually exists.
  return /^[^\s@]+@(gmail\.com|icloud\.com)$/i.test(email.trim());
}

function generateSignInCode(){
  return String(Math.floor(100000 + Math.random()*900000));
}

/* ============================================================
   AUTH FLOW
============================================================ */
function goStep(id){
  ['stepWelcome','stepDevPassword','stepVerify','stepSuccess','stepBanned','stepSuspended','stepExited'].forEach(s=>document.getElementById(s).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function openChooser(provider){
  pendingProvider = provider;
  const head = document.getElementById('chooserHead');
  const accWrap = document.getElementById('chooserAccounts');
  if(provider === 'google'){
    head.innerHTML = `<svg viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
      <h3>Choose an account</h3><p>to continue to NovaCore</p>`;
    accWrap.innerHTML = googleAccountRow('Jordan Avery','jordan.avery@gmail.com','JA') + googleAccountRow('Use another account','','+', true);
  } else {
    head.innerHTML = `<svg viewBox="0 0 384 512" fill="#fff"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-14.9 0-49.3-19.7-76.4-19.7C63.3 141 0 184.8 0 273.5c0 26.2 4.8 53.3 14.4 81.2 12.8 37 59 127.7 107.2 126.1 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-83.4 102.6-120.5-65.2-30.7-57.7-90-57.7-91.6zM256.8 88.6c26.9-32 24.5-61.2 23.7-71.6-23.8 1.4-51.3 16.4-67 34.9-17.3 19.8-27.5 44.4-25.4 70.8 25.2 2 48.1-10.9 68.7-34.1z"/></svg>
      <h3>Sign in with Apple ID</h3><p>to continue to NovaCore</p>`;
    accWrap.innerHTML = googleAccountRow('Jordan Avery','jordan.avery@icloud.com','JA');
  }
  document.getElementById('chooserOverlay').classList.remove('hidden');
}

function googleAccountRow(name,email,initials,isAdd){
  return `<div class="chooser-account" onclick="${isAdd? "closeChooser(); document.getElementById('emailInput').focus();" : `pickAccount('${name}','${email}','${initials}')`}">
    <div class="chooser-avatar">${initials}</div>
    <div class="who"><b>${name}</b>${email? `<span>${email}</span>`:''}</div>
  </div>`;
}

function closeChooser(){ document.getElementById('chooserOverlay').classList.add('hidden'); }

function pickAccount(name,email,initials){
  closeChooser();
  state.user.name = name;
  state.user.email = email;
  state.user.initials = initials;
  state.user.provider = pendingProvider === 'google' ? 'Google' : 'Apple';
  pendingVerificationCode = generateSignInCode();
  document.getElementById('verifySub').innerHTML = `We sent a 6-digit code to <b>${email}</b>`;
  document.getElementById('genCodeDisplay').textContent = pendingVerificationCode;
  goStep('stepVerify');
  document.querySelectorAll('.code-row input')[0].focus();
}

function continueWithEmail(){
  const emailField = document.getElementById('emailInput');
  const errEl = document.getElementById('emailFormatError');
  const email = emailField.value.trim();

  if(!isWorkingEmailFormat(email)){
    errEl.classList.remove('hidden');
    shakeField('emailInput');
    return;
  }
  errEl.classList.add('hidden');

  const emailIsAdmin = email.trim().toLowerCase() === ADMIN_EMAIL;
  state.user.email = email;
  state.user.name = emailIsAdmin ? 'NovaCore Admin' : email.split('@')[0].replace(/[._]/g,' ').replace(/\b\w/g, c=>c.toUpperCase());
  state.user.initials = state.user.name.slice(0,1).toUpperCase();
  state.user.provider = 'Email';

  if(emailIsAdmin){
    // developer accounts go through a password gate instead of the emailed code
    pendingAdminEmail = email;
    document.getElementById('devPassSub').innerHTML = `Enter the developer password for <b>${email}</b>.`;
    document.getElementById('devPasswordInput').value = '';
    document.getElementById('devPassError').classList.add('hidden');
    goStep('stepDevPassword');
    document.getElementById('devPasswordInput').focus();
    return;
  }

  pendingVerificationCode = generateSignInCode();
  document.getElementById('verifySub').innerHTML = `We sent a 6-digit code to <b>${email}</b>`;
  document.getElementById('genCodeDisplay').textContent = pendingVerificationCode;
  goStep('stepVerify');
  document.querySelectorAll('.code-row input')[0].focus();
}

function checkDevPassword(){
  const input = document.getElementById('devPasswordInput');
  const errEl = document.getElementById('devPassError');
  if(input.value !== ADMIN_PASSWORD){
    errEl.classList.remove('hidden');
    shakeField('devPasswordInput');
    return;
  }
  errEl.classList.add('hidden');
  goStep('stepSuccess');
  setTimeout(proceedPastVerification, 900);
}

function shakeField(id){
  const el = document.getElementById(id);
  el.style.borderColor = 'var(--red)';
  setTimeout(()=> el.style.borderColor='', 900);
}

// code inputs auto-advance
document.addEventListener('input', (e)=>{
  if(e.target.matches('.code-row input')){
    const inputs = [...document.querySelectorAll('.code-row input')];
    const i = inputs.indexOf(e.target);
    if(e.target.value && i < inputs.length-1) inputs[i+1].focus();
  }
});

function verifyCode(){
  const code = [...document.querySelectorAll('.code-row input')].map(i=>i.value).join('');
  if(code.length < 6 || code !== pendingVerificationCode){
    document.querySelectorAll('.code-row input').forEach(i=>{i.style.borderColor='var(--red)'; setTimeout(()=>i.style.borderColor='',800);});
    return;
  }
  goStep('stepSuccess');
  setTimeout(proceedPastVerification, 1100);
}

function proceedPastVerification(){
  const record = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());

  if(record && record.status === 'banned'){
    showBanScreen(record);
    return;
  }

  if(record && record.status === 'suspended'){
    const totalMs = (record.suspendDays || 0) * 86400000;
    const elapsed = Date.now() - (record.suspendedAt || Date.now());
    if(record.suspendedAt && elapsed >= totalMs){
      // the suspension period has genuinely passed — really lift it, not just cosmetically
      record.status = 'active';
      record.suspendDays = null;
      record.suspendedAt = null;
      saveToStorage();
    } else {
      showSuspendScreen(record);
      return;
    }
  }

  enterApp();
}

function formatTimeRemaining(record){
  const totalMs = (record.suspendDays || 0) * 86400000;
  const elapsed = Date.now() - (record.suspendedAt || Date.now());
  const remainingMs = Math.max(0, totalMs - elapsed);
  const days = Math.floor(remainingMs / 86400000);
  const hrs = Math.floor((remainingMs % 86400000) / 3600000);
  if(days > 0) return `${days}d ${hrs}h`;
  if(hrs > 0) return `${hrs}h`;
  return 'less than an hour';
}

function showBanScreen(record){
  document.getElementById('bannedSub').textContent = `This NovaCore account (${record.email}) has been permanently banned for violating our Community Guidelines.`;
  goStep('stepBanned');
}

function showSuspendScreen(record){
  const remaining = formatTimeRemaining(record);
  document.getElementById('suspendedSub').textContent = `Your account (${record.email}) is suspended for ${record.suspendDays} day${record.suspendDays>1?'s':''} — about ${remaining} left. It's lifted automatically once that ends, no need to come back and check.`;
  goStep('stepSuspended');
}

function switchToNewAccount(){
  pendingVerificationCode = null;
  document.getElementById('emailInput').value = '';
  document.querySelectorAll('.code-row input').forEach(i => i.value = '');
  state.user = { name:'', email:'', provider:'', initials:'N', isAdmin:false, isDeveloper:false, id:null, avatarImage:null };
  goStep('stepWelcome');
}

function exitNovaCore(){
  // Browsers block window.close() on tabs they didn't open themselves — this is normal,
  // not a bug — so either way we land on a clear "you've left" screen as a fallback.
  try{ window.close(); }catch(e){ /* expected in most browsers */ }
  setTimeout(()=> goStep('stepExited'), 50);
}

function forceExitToStatusScreen(record){
  document.getElementById('avatarDropdown').classList.add('hidden');
  document.getElementById('app').classList.add('hidden');
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('adminSearchWrap').classList.add('hidden');
  toggleAI(false);
  if(record.status === 'banned') showBanScreen(record);
  else showSuspendScreen(record);
}

function enterApp(){
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');

  const isAdmin = state.user.email.trim().toLowerCase() === ADMIN_EMAIL;
  state.user.isAdmin = isAdmin;
  state.user.isDeveloper = isAdmin;

  // find or create this person's directory record + unique ID
  let record = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(!record){
    record = {
      id: genUniqueId(), name: state.user.name, email: state.user.email,
      role: isAdmin ? 'admin' : 'user', status:'active', warnings:0, suspendDays:null, joined:'Jul 2026'
    };
    state.users.push(record);
  }
  state.user.id = record.id;
  record.isOnline = true;
  saveToStorage();

  // a returning account (within this browser session) keeps its custom name/photo
  if(record.displayName){
    state.user.name = record.displayName;
    state.user.initials = record.displayName.slice(0,1).toUpperCase();
  }
  state.user.recordDisplayName = !!record.displayName;
  state.user.avatarImage = record.avatarImage || null;

  // fresh (non-admin) accounts start at zero — payout method OPTIONS stay available,
  // real balances/earnings only grow once you actually buy or sell something
  if(!isAdmin){
    state.balance = { available:0, pending:0 };
    state.stats = { totalSales:0, totalPurchases:0, totalEarned:0 };
    state.transactions = [];
    state.monthly = state.monthly.map(m => ({ ...m, v:0 }));
  }

  document.getElementById('avatarChip').innerHTML = state.user.avatarImage ? `<img src="${state.user.avatarImage}" alt="">` : state.user.initials;
  document.getElementById('ddName').innerHTML = state.user.name + (state.user.isDeveloper ? ' <span class="dev-badge">Developer</span>' : '');
  document.getElementById('ddEmail').textContent = state.user.email;
  document.getElementById('ddId').textContent = 'ID #' + state.user.id;
  document.getElementById('adminSearchWrap').classList.toggle('hidden', !isAdmin);

  buildTabs();
  showPage('home');
  seedAIWelcome();

  if(!record.agreedToGuidelines){
    document.getElementById('guidelinesCheck').checked = false;
    document.getElementById('guidelinesContinueBtn').disabled = true;
    document.getElementById('guidelinesOverlay').classList.remove('hidden');
  } else if(!record.device){
    document.getElementById('deviceChoiceOverlay').classList.remove('hidden');
  } else {
    state.user.device = record.device;
    applyDeviceView(record.device);
  }
}

function acceptGuidelines(){
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(rec) rec.agreedToGuidelines = true;
  document.getElementById('guidelinesOverlay').classList.add('hidden');
  saveToStorage();
  if(rec && !rec.device){
    document.getElementById('deviceChoiceOverlay').classList.remove('hidden');
  }
}

function applyDeviceView(device){
  document.body.classList.remove('force-mobile','force-desktop');
  document.body.classList.add(device === 'phone' ? 'force-mobile' : 'force-desktop');
}

function chooseDevice(device){
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(rec) rec.device = device;
  state.user.device = device;
  applyDeviceView(device);
  saveToStorage();
  document.getElementById('deviceChoiceOverlay').classList.add('hidden');
  showToast(`Viewing NovaCore as ${device === 'phone' ? 'a phone' : 'a computer'}`);
  if(state.activeTab === 'settings') showPage('settings');
}

function signOut(){
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(rec) rec.isOnline = false;
  saveToStorage();
  document.getElementById('avatarDropdown').classList.add('hidden');
  document.getElementById('app').classList.add('hidden');
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('adminSearchWrap').classList.add('hidden');
  document.getElementById('guidelinesOverlay').classList.add('hidden');
  document.getElementById('deviceChoiceOverlay').classList.add('hidden');
  document.body.classList.remove('force-mobile','force-desktop');
  goStep('stepWelcome');
  document.getElementById('emailInput').value='';
  document.querySelectorAll('.code-row input').forEach(i=>i.value='');
  toggleAI(false);
  aiHistory = [];
  pendingVerificationCode = null;
  state.user = { name:'', email:'', provider:'', initials:'N', isAdmin:false, isDeveloper:false, id:null };
}

/* ============================================================
   NAV / TABS
============================================================ */
function buildTabs(){
  const nav = document.getElementById('tabNav');
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  let tabs = CATS.map(c=>{
    let label = c.label;
    if(c.id === 'inbox' && rec){
      const unread = getUnreadInboxCount(rec);
      if(unread > 0) label += ` <span class="tab-badge">${unread}</span>`;
    }
    return `<button class="tab-btn" id="tab-${c.id}" onclick="showPage('${c.id}')">${label}</button>`;
  }).join('');
  if(state.user.isAdmin){
    tabs += `<button class="tab-btn admin-tab" id="tab-admin" onclick="showPage('admin')">🛠️ Developer menu</button>`;
  }
  nav.innerHTML = tabs;
}

function setActiveTab(id){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  const btn = document.getElementById('tab-'+id);
  if(btn) btn.classList.add('active');
}

function showPage(id){
  state.activeTab = id;
  setActiveTab(id);
  const main = document.getElementById('mainArea');
  if(id === 'home') main.innerHTML = renderHomePage();
  else if(id === 'search') main.innerHTML = renderSearchPage();
  else if(id === 'inbox') main.innerHTML = renderInboxPage();
  else if(id === 'messages') main.innerHTML = renderMessagesPage();
  else if(['games','shoes','clothing','jewelry','electronics','furniture'].includes(id)) main.innerHTML = renderListingsPage(id, CATS.find(c=>c.id===id).label, `Browse ${CATS.find(c=>c.id===id).label.toLowerCase()} listed by other NovaCore sellers.`);
  else if(id === 'sales') main.innerHTML = renderSalesPage();
  else if(id === 'payments') main.innerHTML = renderPaymentsPage();
  else if(id === 'settings') main.innerHTML = renderSettingsPage();
  else if(id === 'admin') main.innerHTML = renderAdminPage();
  document.getElementById('avatarDropdown').classList.add('hidden');
  window.scrollTo({top:0, behavior:'smooth'});
}

/* ---------- home page (hero + category rail + featured listings) ---------- */
function renderHomePage(){
  const first = state.user.name ? state.user.name.split(' ')[0] : '';
  const totalListings = LISTINGS.length;
  const totalSellers = new Set(LISTINGS.map(i=>i.seller)).size;
  const featured = LISTINGS.slice(0, 8);
  const heroStatListings = totalListings > 0
    ? `<div class="hero-stat"><b>${totalListings}</b><span>Active listings</span></div><div class="hero-stat"><b>${totalSellers}</b><span>Verified sellers</span></div>`
    : `<div class="hero-stat"><b>5</b><span>Categories open now</span></div>`;

  return `
  <div class="page">
    <div class="home-hero">
      <div class="hero-inner">
        <div class="hero-copy">
          <div class="hero-eyebrow">Verified marketplace</div>
          <h1>${first ? `Welcome back, ${first}.` : 'Welcome to'} <span class="accent-word">Buy and sell,<br>backed by NovaCore.</span></h1>
          <p class="hero-sub">Real people, verified listings, and fair fees — browse games, shoes, clothing, jewelry, and electronics, or list something in under a minute.</p>
          <div class="hero-actions">
            <button class="btn-primary" style="width:auto; padding:12px 24px;" onclick="openListModal()">+ List an item</button>
            <button class="btn-ghost" onclick="toggleAI(true)">Ask Nova AI for help</button>
          </div>
          <div class="hero-stats">
            ${heroStatListings}
            <div class="hero-stat"><b>8%</b><span>Fee on the free plan</span></div>
          </div>
        </div>
        <div class="hero-visual">
          <svg viewBox="0 0 220 220">
            <defs>
              <radialGradient id="heroGlow" cx="50%" cy="50%" r="55%">
                <stop offset="0%" stop-color="#d8ceff"/>
                <stop offset="45%" stop-color="#7c5cff"/>
                <stop offset="100%" stop-color="#3ddceb"/>
              </radialGradient>
            </defs>
            <circle class="ring" cx="110" cy="110" r="95" fill="none" stroke="#3ddceb" stroke-width="1.4" stroke-dasharray="2 10" opacity="0.55"/>
            <circle class="ring2" cx="110" cy="110" r="72" fill="none" stroke="#9d85ff" stroke-width="1.4" stroke-dasharray="1 8" opacity="0.5"/>
            <circle cx="110" cy="110" r="40" fill="url(#heroGlow)"/>
          </svg>
        </div>
      </div>
    </div>

    <div class="home-search">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
      <input type="text" id="homeSearchInput" placeholder="Search listings by name or model…" onkeydown="if(event.key==='Enter')performSearch(this.value)">
      <button class="btn-primary" style="width:auto; padding:10px 20px;" onclick="performSearch(document.getElementById('homeSearchInput').value)">Search</button>
    </div>

    <div class="cat-rail">
      ${['games','shoes','clothing','jewelry','electronics','furniture'].map(c => `
        <button class="cat-chip" onclick="showPage('${c}')">
          ${catIcon(c, 30)}
          ${CATS.find(x=>x.id===c).label}
        </button>`).join('')}
    </div>

    <div class="section-head">
      <h3>Fresh finds</h3>
      <span class="section-sub">Newest listings across every category</span>
    </div>
    ${featured.length ? `<div class="grid">${featured.map(renderCard).join('')}</div>` : renderEmptyListings('listings')}
  </div>`;
}

let currentSearchQuery = '';

function performSearch(q){
  q = (q || '').trim();
  if(!q) return;
  currentSearchQuery = q;
  showPage('search');
}

function renderSearchPage(){
  const q = currentSearchQuery.toLowerCase();
  const results = applyPriceFilter(LISTINGS.filter(i =>
    i.title.toLowerCase().includes(q) || i.model.toLowerCase().includes(q) || i.cat.toLowerCase().includes(q)
  ));
  return `
  <div class="page">
    <div class="page-head">
      <div><h2>Search results</h2><p>${results.length} match${results.length===1?'':'es'} for "${currentSearchQuery}"</p></div>
      <button class="btn-ghost" onclick="showPage('home')">← Back to Home</button>
    </div>
    ${renderPriceFilterBar()}
    ${results.length ? `<div class="grid">${results.map(renderCard).join('')}</div>` : `
    <div class="empty-listings">
      <div class="empty-listings-ic"><svg viewBox="0 0 48 48" fill="none" stroke="var(--violet-soft)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="21" cy="21" r="13"/><path d="M30 30l9 9"/></svg></div>
      <h4>No matches for "${currentSearchQuery}"</h4>
      <p>Try a different keyword, or browse by category from the nav above.</p>
    </div>`}
  </div>`;
}

function renderListingsPage(cat, title, sub){
  const items = applyPriceFilter(cat==='home' ? LISTINGS : LISTINGS.filter(i=>i.cat===cat));
  return `
  <div class="page">
    <div class="page-head">
      <div><h2>${title}</h2><p>${sub}</p></div>
      <button class="btn-ghost accent" onclick="openListModal()">+ List an item</button>
    </div>
    ${renderPriceFilterBar()}
    ${items.length ? `<div class="grid">${items.map(renderCard).join('')}</div>` : renderEmptyListings(title)}
  </div>`;
}

function renderEmptyListings(catLabel){
  return `
  <div class="empty-listings">
    <div class="empty-listings-ic">
      <svg viewBox="0 0 48 48" fill="none" stroke="var(--violet-soft)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="14" width="32" height="24" rx="4"/><path d="M8 22h32M16 14v-3a2 2 0 012-2h12a2 2 0 012 2v3"/></svg>
    </div>
    <h4>No ${catLabel.toLowerCase()} listed yet</h4>
    <p>Be the first NovaCore seller in this category — it only takes a minute.</p>
    <button class="btn-primary" style="width:auto; padding:11px 22px;" onclick="openListModal()">+ List an item</button>
  </div>`;
}

/* ---------- Inbox page ---------- */
function renderInboxPage(){
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  const items = getInboxItems();
  if(rec) rec.inboxSeenIds = items.map(i => i.id);
  buildTabs(); // clears the unread badge now that these have been seen

  return `
  <div class="page">
    <div class="page-head"><div><h2>📥 Inbox</h2><p>Coupons, announcements, and updates from the NovaCore team.</p></div></div>
    <div class="inbox-list">
      ${items.map(it => renderInboxItem(it, rec)).join('')}
    </div>
  </div>`;
}

function renderInboxItem(it, rec){
  if(it.type === 'coupon'){
    const claimed = rec && rec.claimedCoupons && rec.claimedCoupons.includes(it.code);
    return `
    <div class="inbox-item coupon">
      <div class="inbox-ic">${it.icon}</div>
      <div class="inbox-body">
        <b>${it.title}</b>
        <span>${it.body}</span>
        <span class="inbox-time">${it.time} · code ${it.code}</span>
      </div>
      ${claimed ? `<span class="connected-tag">✓ Claimed</span>` : `<button class="btn-primary" style="width:auto; padding:9px 16px;" onclick="claimCoupon('${it.code}')">Claim</button>`}
    </div>`;
  }
  return `
  <div class="inbox-item">
    <div class="inbox-ic">${it.icon}</div>
    <div class="inbox-body">
      <b>${it.title}</b>
      <span>${it.body}</span>
      <span class="inbox-time">${it.time}</span>
    </div>
  </div>`;
}

function claimCoupon(code){
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(!rec) return;
  rec.claimedCoupons = rec.claimedCoupons || [];
  if(!rec.claimedCoupons.includes(code)) rec.claimedCoupons.push(code);
  saveToStorage();
  showPage('inbox');
  showToast(`Coupon ${code} claimed`);
}

function toggleNotifPref(key, el){
  state.notifPrefs[key] = !state.notifPrefs[key];
  el.classList.toggle('on');
  saveToStorage();
  buildTabs();
}

/* ---------- Messages page (per-item conversations with sellers) ---------- */
let openConversationId = null;

function convoId(itemId, seller){ return itemId + '::' + seller; }
function nowTimeLabel(){ return new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }); }

function openConversation(itemId){
  const item = LISTINGS.find(i => i.id === itemId);
  if(!item) return;
  const id = convoId(itemId, item.seller);
  if(!state.conversations[id]){
    state.conversations[id] = {
      itemId, itemTitle:item.title, sellerName:item.seller,
      messages:[{ from:'them', text:`Hi! Thanks for your interest in the ${item.title}. Let me know if you have any questions.`, time: nowTimeLabel() }]
    };
    saveToStorage();
  }
  closeItemModal();
  state.activeTab = 'messages';
  setActiveTab('messages');
  viewConversation(id);
  window.scrollTo({top:0, behavior:'smooth'});
}

function viewConversation(id){
  openConversationId = id;
  renderConvoInPlace(id);
}

function backToConvoList(){
  openConversationId = null;
  showPage('messages');
}

function renderConvoInPlace(id){
  document.getElementById('mainArea').innerHTML = renderConversationThread(id);
  const box = document.getElementById('convoMessages');
  if(box) box.scrollTop = box.scrollHeight;
  const input = document.getElementById('convoInputBox');
  if(input) input.focus();
}

function renderMessagesPage(){
  const convos = Object.entries(state.conversations);
  if(!convos.length){
    return `
    <div class="page">
      <div class="page-head"><div><h2>💬 Messages</h2><p>Conversations with sellers and buyers about specific items.</p></div></div>
      <div class="empty-listings">
        <div class="empty-listings-ic"><svg viewBox="0 0 48 48" fill="none" stroke="var(--violet-soft)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 12h32v20H16l-8 8z"/></svg></div>
        <h4>No conversations yet</h4>
        <p>Message a seller from any item's page to start chatting about it.</p>
      </div>
    </div>`;
  }
  return `
  <div class="page">
    <div class="page-head"><div><h2>💬 Messages</h2><p>Conversations with sellers and buyers about specific items.</p></div></div>
    <div class="convo-list">
      ${convos.map(([id,c])=>{
        const last = c.messages[c.messages.length-1];
        const preview = last.text.length > 46 ? last.text.slice(0,46)+'…' : last.text;
        return `
        <div class="convo-row" onclick="viewConversation('${id}')">
          <div class="admin-avatar">${c.sellerName.slice(0,1).toUpperCase()}</div>
          <div class="convo-info"><b>${c.sellerName}</b><span>${c.itemTitle}</span></div>
          <span class="convo-last">${preview}</span>
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

function renderConversationThread(id){
  const c = state.conversations[id];
  return `
  <div class="page">
    <button class="btn-ghost" style="margin-bottom:14px;" onclick="backToConvoList()">◀ All conversations</button>
    <div class="panel convo-thread-panel">
      <div class="convo-thread-head">
        <div class="admin-avatar">${c.sellerName.slice(0,1).toUpperCase()}</div>
        <div><b>${c.sellerName}</b><span>${c.itemTitle}</span></div>
      </div>
      <div class="convo-thread-messages" id="convoMessages">
        ${c.messages.map(m=>`
          <div class="msg-row ${m.from==='me'?'user':'assistant'}">
            <div class="msg-col">
              <div class="msg ${m.from==='me'?'user':'assistant'}">${m.text}</div>
              <div class="msg-time">${m.time}</div>
            </div>
          </div>`).join('')}
      </div>
      <div class="ai-input convo-input-row">
        <input type="text" id="convoInputBox" placeholder="Message ${c.sellerName}…" onkeydown="if(event.key==='Enter')sendThreadMessage('${id}')">
        <button class="send-btn" onclick="sendThreadMessage('${id}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
        </button>
      </div>
    </div>
  </div>`;
}

const CANNED_SELLER_REPLIES = [
  "Thanks for reaching out — happy to answer anything about it.",
  "Sure, that works for me!",
  "Yep, it's still available.",
  "I can do that — just let me know what works best for you.",
  "Good question — it's exactly as described in the listing.",
];

function sendThreadMessage(id){
  const input = document.getElementById('convoInputBox');
  const text = input.value.trim();
  if(!text) return;
  input.value = '';
  const c = state.conversations[id];
  c.messages.push({ from:'me', text, time: nowTimeLabel() });
  saveToStorage();
  renderConvoInPlace(id);
  setTimeout(()=>{
    const reply = CANNED_SELLER_REPLIES[Math.floor(Math.random()*CANNED_SELLER_REPLIES.length)];
    c.messages.push({ from:'them', text:reply, time: nowTimeLabel() });
    saveToStorage();
    if(openConversationId === id) renderConvoInPlace(id);
  }, 1100);
}

function renderCard(item){
  return `
  <div class="card" onclick="openItemModal(${item.id})">
    <div class="card-media" style="background:${item.image ? '#0d1120' : CAT_GRADIENT[item.cat]}">
      <span class="cat-tag">${item.cat}</span>${item.image ? `<img src="${item.image}" alt="${item.title}">` : CAT_ICON[item.cat]}
    </div>
    <div class="card-body">
      <h4>${item.title}</h4>
      <div class="model">Model ${item.model} · ${item.seller}</div>
      <div class="card-foot"><span class="price">$${item.price.toLocaleString()}</span><span class="cond-pill">${item.cond}</span></div>
      <div class="card-actions">
        <button class="buy-btn" onclick="event.stopPropagation(); quickBuy(${item.id})">Buy now</button>
        <button class="offer-btn" onclick="event.stopPropagation(); openItemModal(${item.id}, true)">Make offer</button>
      </div>
    </div>
  </div>`;
}

/* ---------- item modal ---------- */
function openItemModal(id, focusOffer){
  currentItemId = id;
  const item = LISTINGS.find(i=>i.id===id);
  document.getElementById('itemModalCard').innerHTML = `
    <button class="close-x" onclick="closeItemModal()">&times;</button>
    <h3>${item.title}</h3>
    <div class="modal-media" style="background:${item.image ? '#0d1120' : CAT_GRADIENT[item.cat]}">${item.image ? `<img src="${item.image}" alt="${item.title}">` : CAT_ICON[item.cat]}</div>
    <div class="detail-row"><span>Model / SKU</span><span>${item.model}</span></div>
    <div class="detail-row"><span>Category</span><span style="text-transform:capitalize;">${item.cat}</span></div>
    <div class="detail-row"><span>Condition</span><span>${item.cond}</span></div>
    <div class="detail-row"><span>Seller</span><span>${item.seller}</span></div>
    <div class="detail-row"><span>Asking price</span><span style="color:var(--green);">$${item.price.toLocaleString()}</span></div>
    <p style="font-size:13px; color:var(--text-muted); margin:14px 0; line-height:1.6;">${item.desc}</p>
    <div class="seg-toggle">
      <button id="segBuy" class="active" onclick="setModalMode('buy')">Buy now</button>
      <button id="segOffer" onclick="setModalMode('offer')">Make an offer</button>
    </div>
    <div id="modeBuy">
      <button class="btn-primary" onclick="confirmBuy(${item.id})">Confirm purchase — $${item.price.toLocaleString()}</button>
    </div>
    <div id="modeOffer" class="hidden">
      <div class="field"><label>Your offer amount ($)</label><input type="number" id="offerAmount" placeholder="e.g. ${Math.round(item.price*0.85)}"></div>
      <div class="field"><label>Message to seller (mention the item & model)</label><textarea id="offerMsg" rows="3" style="width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface-2); color:var(--text); outline:none; font-size:13.5px; resize:vertical;" placeholder="Hi, I'm interested in the ${item.title} (model ${item.model}). Would you accept...">Hi, I'm interested in the ${item.title} (model ${item.model}). Would you accept</textarea></div>
      <button class="btn-primary" onclick="submitOffer(${item.id})">Send offer to ${item.seller}</button>
    </div>
    <button class="btn-ghost" style="width:100%; justify-content:center; margin-top:10px;" onclick="openConversation(${item.id})">💬 Message ${item.seller}</button>
  `;
  document.getElementById('itemModalOverlay').classList.remove('hidden');
  if(focusOffer) setModalMode('offer');
}

function setModalMode(mode){
  document.getElementById('segBuy').classList.toggle('active', mode==='buy');
  document.getElementById('segOffer').classList.toggle('active', mode==='offer');
  document.getElementById('modeBuy').classList.toggle('hidden', mode!=='buy');
  document.getElementById('modeOffer').classList.toggle('hidden', mode!=='offer');
}

function closeItemModal(){ document.getElementById('itemModalOverlay').classList.add('hidden'); }
function quickBuy(id){ openItemModal(id); confirmBuy(id); }

// Buying or selling now actually moves the needle on your balance/earnings/purchases.
function confirmBuy(id){
  const idx = LISTINGS.findIndex(i=>i.id===id);
  if(idx === -1) return; // already sold/removed — nothing to do
  const item = LISTINGS[idx];
  const youAreSeller = item.seller === (state.user.name || 'You');
  if(youAreSeller){
    const feeRate = FEE_RATES[state.currentPlan] ?? FEE_RATES.basic;
    const earned = +(item.price * (1 - feeRate)).toFixed(2);
    state.stats.totalSales += 1;
    state.stats.totalEarned = +(state.stats.totalEarned + earned).toFixed(2);
    state.balance.available = +(state.balance.available + earned).toFixed(2);
    state.monthly[state.monthly.length - 1].v = +(state.monthly[state.monthly.length - 1].v + earned).toFixed(2);
    state.transactions.unshift({ title:`Sold — ${item.title}`, sub:`to a NovaCore buyer · just now`, amt:earned, type:'pos', icon:CAT_EMOJI[item.cat] || '🛍️' });
    closeItemModal();
    showToast(`Sold ${item.title} for $${earned.toLocaleString()} after fees`);
  } else {
    state.stats.totalPurchases += 1;
    state.balance.available = +(state.balance.available - item.price).toFixed(2);
    state.transactions.unshift({ title:`Bought — ${item.title}`, sub:`from ${item.seller} · just now`, amt:-item.price, type:'neg', icon:CAT_EMOJI[item.cat] || '🛍️' });
    closeItemModal();
    showToast(`Purchase confirmed — ${item.title} for $${item.price.toLocaleString()}`);
  }
  LISTINGS.splice(idx, 1); // sold — remove so it can't be bought again
  saveToStorage();
  showPage(state.activeTab); // refresh whatever page was actually open, not just Sales/Payments
}

function submitOffer(id){
  const item = LISTINGS.find(i=>i.id===id);
  const amt = document.getElementById('offerAmount').value;
  if(!amt || Number(amt) <= 0){ shakeField('offerAmount'); return; }
  state.offers.push({ itemId:id, amount:Number(amt), msg:document.getElementById('offerMsg').value });
  closeItemModal();
  showToast(`Offer of $${Number(amt).toLocaleString()} sent to ${item.seller}`);
}

let pendingListingImage = null;

function openListModal(){
  pendingListingImage = null;
  document.getElementById('listModalCard').innerHTML = `
    <button class="close-x" onclick="document.getElementById('listModalOverlay').classList.add('hidden')">&times;</button>
    <h3>List a new item</h3>
    <p style="font-size:12.5px; color:var(--text-muted); margin-bottom:14px;">Tell buyers exactly what it is — the item name, model/SKU, and condition help you sell faster.</p>
    <div class="field">
      <label>Photo</label>
      <div class="photo-picker">
        <input type="file" accept="image/*" id="newImageInput" onchange="previewNewImage(event)">
        <label for="newImageInput" class="photo-picker-btn" id="photoPickerLabel">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10.5" r="1.5"/><path d="M21 16l-5-5-4 4-3-3-5 5"/></svg>
          Choose a photo from your device
        </label>
        <div class="photo-preview hidden" id="newImagePreview">
          <img id="newImagePreviewImg" alt="Listing preview">
          <button type="button" class="photo-remove" onclick="clearNewImage()">&times;</button>
        </div>
      </div>
    </div>
    <div class="field"><label>Item title</label><input id="newTitle" placeholder="e.g. Sony PS5 console"></div>
    <div class="field"><label>Model / SKU</label><input id="newModel" placeholder="e.g. CFI-2000A"></div>
    <div class="field"><label>Category</label>
      <select id="newCat" style="width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface-2); color:var(--text);">
        <option value="games">Games</option><option value="shoes">Shoes</option><option value="clothing">Clothing</option>
        <option value="jewelry">Jewelry</option><option value="electronics">Electronics</option><option value="furniture">Furniture</option>
      </select>
    </div>
    <div class="field"><label>Price ($)</label><input id="newPrice" type="number" placeholder="e.g. 250"></div>
    <div class="field"><label>Condition</label>
      <select id="newCond" style="width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface-2); color:var(--text);">
        <option>New</option><option>Like New</option><option>Good</option><option>Fair</option>
      </select>
    </div>
    <button class="btn-primary" onclick="submitListing()">Publish listing</button>
  `;
  document.getElementById('listModalOverlay').classList.remove('hidden');
}

function previewNewImage(e){
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(ev){
    pendingListingImage = ev.target.result;
    document.getElementById('newImagePreviewImg').src = pendingListingImage;
    document.getElementById('newImagePreview').classList.remove('hidden');
    document.getElementById('photoPickerLabel').classList.add('hidden');
  };
  reader.readAsDataURL(file);
}

function clearNewImage(){
  pendingListingImage = null;
  const input = document.getElementById('newImageInput');
  if(input) input.value = '';
  document.getElementById('newImagePreview').classList.add('hidden');
  document.getElementById('photoPickerLabel').classList.remove('hidden');
}

function submitListing(){
  const title = document.getElementById('newTitle').value.trim();
  const price = Number(document.getElementById('newPrice').value);
  if(!title || !price){ showToast('Add a title and price to publish.'); return; }
  const cat = document.getElementById('newCat').value;
  LISTINGS.unshift({
    id: Date.now(), cat, title,
    model: document.getElementById('newModel').value || 'N/A',
    price, cond: document.getElementById('newCond').value,
    seller: state.user.name || 'You', desc: 'Listed by you just now.',
    image: pendingListingImage || null
  });
  pendingListingImage = null;
  saveToStorage();
  document.getElementById('listModalOverlay').classList.add('hidden');
  showToast('Listing published to NovaCore');
  showPage(cat);
}

/* ============================================================
   SALES / DASHBOARD PAGE
============================================================ */
function renderSalesPage(){
  const maxV = Math.max(1, ...state.monthly.map(m=>m.v));
  return `
  <div class="page">
    <div class="page-head"><div><h2>My sales</h2><p>How your NovaCore store is performing.</p></div></div>
    <div class="stat-row">
      <div class="stat-card"><div class="label">📦 Total sales</div><div class="value">${state.stats.totalSales}</div><div class="delta">Lifetime items sold</div></div>
      <div class="stat-card"><div class="label">🛒 Total purchases</div><div class="value">${state.stats.totalPurchases}</div><div class="delta">Items you've bought</div></div>
      <div class="stat-card"><div class="label">💰 Total earned</div><div class="value">$${state.stats.totalEarned.toLocaleString(undefined,{minimumFractionDigits:2})}</div><div class="delta">Lifetime revenue</div></div>
    </div>
    <div class="settings-grid">
      <div class="panel">
        <h3>Earnings — last 6 months</h3>
        <div class="bars">
          ${state.monthly.map(m=>`<div class="bar-col"><div class="bar" style="height:${(m.v/maxV*100)}%"></div><span>${m.m}</span></div>`).join('')}
        </div>
      </div>
      <div class="panel">
        <h3>Recent activity</h3>
        <div class="tx-list">
          ${state.transactions.length ? state.transactions.slice(0,5).map(t=>`
            <div class="tx-row">
              <div class="tx-left"><div class="tx-icon">${t.icon}</div><div><div class="tx-title">${t.title}</div><div class="tx-sub">${t.sub}</div></div></div>
              <div class="tx-amt ${t.type}">${t.type==='pos'?'+':'-'}$${Math.abs(t.amt).toLocaleString()}</div>
            </div>`).join('') : `<div class="empty-note">No activity yet — buy or list something to get started.</div>`}
        </div>
      </div>
    </div>
  </div>`;
}

/* ============================================================
   PAYMENTS PAGE
============================================================ */
const METHOD_META = {
  applepay: { name:'Apple Pay', icon:'', svg:true, desc:'Fast checkout & instant payouts' },
  cashapp: { name:'Cash App', icon:'💵', desc:'Send payouts to your $cashtag' },
  card: { name:'Debit / Credit Card', icon:'💳', desc:'Visa, Mastercard, Amex & more' },
  bank: { name:'Bank account', icon:'🏦', desc:'Direct deposit via routing & account #' },
};

function renderPaymentsPage(){
  return `
  <div class="page">
    <div class="page-head"><div><h2>Payments & payouts</h2><p>Connect a payout method, manage your balance, and pick a seller plan.</p></div></div>
    <div class="balance-banner">
      <div><div class="lbl">Available balance</div><div class="amt">$${state.balance.available.toLocaleString(undefined,{minimumFractionDigits:2})}</div></div>
      <div><div class="lbl">Pending clearance</div><div class="amt" style="font-size:20px; color:var(--text-muted);">$${state.balance.pending.toLocaleString(undefined,{minimumFractionDigits:2})}</div></div>
      <button class="btn-primary" style="width:auto; padding:12px 22px;" onclick="requestPayout()">Request payout</button>
    </div>
    <h3 style="font-family:var(--font-display); font-size:16px; margin-bottom:14px;">Payout methods</h3>
    <div class="pay-grid">
      ${Object.keys(METHOD_META).map(k=>renderMethodCard(k)).join('')}
    </div>
    <h3 style="font-family:var(--font-display); font-size:16px; margin:28px 0 4px;">Seller plans</h3>
    <p style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Lower fees and faster payouts as you grow.</p>
    <div class="plans-grid">
      ${renderPlanCard('basic','Basic','$0/mo','8% selling fee',['Unlimited listings','Standard 3–5 day payouts','Community support'])}
      ${renderPlanCard('pro','Pro','$9.99/mo','5% selling fee',['Priority placement','1–2 day payouts','Nova AI listing assistant'])}
      ${renderPlanCard('business','Business','$29.99/mo','3% selling fee',['Instant payouts','Bulk listing tools','Dedicated support line'])}
    </div>
  </div>`;
}

function renderMethodCard(key){
  const m = state.methods[key];
  const meta = METHOD_META[key];
  return `
  <div class="method-card">
    <div class="method-head">
      <div class="method-title">
        <div class="m-icon">${meta.svg ? appleIcon() : meta.icon}</div>
        <div><b>${meta.name}</b><span>${meta.desc}</span></div>
      </div>
      ${m.connected ? `<span class="connected-tag">${m.label}</span>` : `<button class="btn-ghost" onclick="toggleMethodForm('${key}')">Connect</button>`}
    </div>
    <div class="method-connect-form" id="form-${key}">
      ${renderMethodForm(key)}
    </div>
  </div>`;
}

function appleIcon(){ return `<svg width="18" height="18" viewBox="0 0 384 512" fill="#fff"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-14.9 0-49.3-19.7-76.4-19.7C63.3 141 0 184.8 0 273.5c0 26.2 4.8 53.3 14.4 81.2 12.8 37 59 127.7 107.2 126.1 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-83.4 102.6-120.5-65.2-30.7-57.7-90-57.7-91.6zM256.8 88.6c26.9-32 24.5-61.2 23.7-71.6-23.8 1.4-51.3 16.4-67 34.9-17.3 19.8-27.5 44.4-25.4 70.8 25.2 2 48.1-10.9 68.7-34.1z"/></svg>`; }

function renderMethodForm(key){
  if(key==='cashapp') return `<div class="field"><label>$Cashtag</label><input id="input-${key}" placeholder="$yourtag"></div><button class="btn-primary" onclick="connectMethod('${key}')">Connect Cash App</button>`;
  if(key==='card') return `<div class="field"><label>Card number</label><input id="input-${key}" placeholder="4242 4242 4242 4242" maxlength="19"></div><button class="btn-primary" onclick="connectMethod('${key}')">Connect card</button>`;
  if(key==='bank') return `<div class="field"><label>Routing & account number</label><input id="input-${key}" placeholder="021000021 / 000123456789"></div><button class="btn-primary" onclick="connectMethod('${key}')">Connect bank</button>`;
  return `<div class="field"><label>Apple ID email</label><input id="input-${key}" placeholder="you@icloud.com"></div><button class="btn-primary" onclick="connectMethod('${key}')">Connect Apple Pay</button>`;
}

function toggleMethodForm(key){
  const el = document.getElementById('form-'+key);
  document.querySelectorAll('.method-connect-form').forEach(f=>{ if(f.id!=='form-'+key) f.classList.remove('show'); });
  el.classList.toggle('show');
}

function connectMethod(key){
  const val = document.getElementById('input-'+key).value.trim();
  if(!val){ shakeField('input-'+key); return; }
  let label = '';
  if(key==='card') label = 'Visa •••• ' + val.replace(/\s/g,'').slice(-4).padStart(4,'0');
  else if(key==='cashapp') label = val.startsWith('$') ? val : '$'+val;
  else if(key==='bank') label = 'Bank •••• ' + val.slice(-4);
  else label = 'Connected';
  state.methods[key] = { connected:true, label };
  showPage('payments');
  showToast(`${METHOD_META[key].name} connected`);
}

function requestPayout(){
  const anyConnected = Object.values(state.methods).some(m=>m.connected);
  if(!anyConnected){ showToast('Connect a payout method first'); return; }
  if(state.balance.available <= 0){ showToast('No available balance to pay out'); return; }
  const amt = state.balance.available;
  const method = Object.entries(state.methods).find(([k,m])=>m.connected);
  state.transactions.unshift({ title:`Payout to ${method[1].label}`, sub:'just now', amt:-amt, type:'neg', icon:'💸' });
  state.balance.available = 0;
  showPage('payments');
  showToast(`$${amt.toLocaleString(undefined,{minimumFractionDigits:2})} payout on its way`);
}

function renderPlanCard(id,name,price,fee,features){
  const current = state.currentPlan === id;
  return `
  <div class="plan-card ${current?'current':''}">
    ${current? '<div class="tag-current">Current plan</div>':''}
    <h4>${name}</h4>
    <div class="p-price">${price}</div>
    <div class="p-fee">${fee}</div>
    <ul>${features.map(f=>`<li>${f}</li>`).join('')}</ul>
    ${current ? `<button class="btn-ghost" style="width:100%; justify-content:center;" disabled>Selected</button>` : `<button class="btn-primary" onclick="selectPlan('${id}','${name}')">Select plan</button>`}
  </div>`;
}

function selectPlan(id,name){ state.currentPlan = id; showPage('payments'); showToast(`Switched to the ${name} plan`); }

/* ============================================================
   SETTINGS PAGE
============================================================ */
function previewAvatarImage(e){
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(ev){
    const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
    if(rec) rec.avatarImage = ev.target.result;
    state.user.avatarImage = ev.target.result;
    saveToStorage();
    refreshAvatarUI();
    if(state.activeTab === 'settings') showPage('settings');
    showToast('Profile photo updated');
  };
  reader.readAsDataURL(file);
}

function refreshAvatarUI(){
  const chip = document.getElementById('avatarChip');
  if(!chip) return;
  chip.innerHTML = state.user.avatarImage ? `<img src="${state.user.avatarImage}" alt="">` : state.user.initials;
}

const NAME_CHANGE_COOLDOWN_MS = 2 * 24 * 60 * 60 * 1000; // 2 days

function saveDisplayName(){
  const input = document.getElementById('setName');
  const newName = input.value.trim();
  const rec = state.users.find(u => u.email.toLowerCase() === state.user.email.toLowerCase());
  if(!rec) return;
  if(!newName){ shakeField('setName'); return; }

  if(rec.nameLastChanged){
    const elapsed = Date.now() - rec.nameLastChanged;
    if(elapsed < NAME_CHANGE_COOLDOWN_MS){
      const hrsLeft = Math.ceil((NAME_CHANGE_COOLDOWN_MS - elapsed) / (60*60*1000));
      showToast(`You can change your name again in about ${hrsLeft}h — names can only change once every 2 days.`);
      return;
    }
  }

  rec.displayName = newName;
  rec.nameLastChanged = Date.now();
  state.user.name = newName;
  state.user.initials = newName.slice(0,1).toUpperCase();
  state.user.recordDisplayName = true;
  saveToStorage();
  refreshIdentityUI();
  showPage('settings');
  showToast('Display name updated');
}

function refreshIdentityUI(){
  const ddName = document.getElementById('ddName');
  if(ddName) ddName.innerHTML = state.user.name + (state.user.isDeveloper ? ' <span class="dev-badge">Developer</span>' : '');
  refreshAvatarUI();
}

function renderSettingsPage(){
  return `
  <div class="page">
    <div class="page-head"><div><h2>Settings</h2><p>Your account, Nova AI, and support.</p></div></div>
    <div class="settings-grid">
      <div class="panel">
        <h3>Profile</h3>
        <div class="field">
          <label>Profile photo</label>
          <div class="photo-picker">
            <input type="file" accept="image/*" id="avatarInput" onchange="previewAvatarImage(event)">
            <label for="avatarInput" class="photo-picker-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10.5" r="1.5"/><path d="M21 16l-5-5-4 4-3-3-5 5"/></svg>
              ${state.user.avatarImage ? 'Change photo' : 'Choose a photo from your device'}
            </label>
          </div>
        </div>
        <div class="field">
          <label>Display name</label>
          <input value="${state.user.name}" id="setName">
          <p class="field-hint">${state.user.recordDisplayName ? "This replaces your Gmail-based name. Names can be changed once every 2 days." : "Shown as your Gmail-based name until you set a custom one — after that, it can be changed once every 2 days."}</p>
        </div>
        <button class="btn-ghost" style="margin:-6px 0 14px;" onclick="saveDisplayName()">Save name</button>
        <div class="field"><label>Email</label><input value="${state.user.email}" id="setEmail" disabled></div>
        <div class="settings-row"><div><div class="s-label">Your NovaCore ID ${state.user.isDeveloper ? '<span class="dev-badge">Developer</span>' : ''}</div><div class="s-sub">Unique to your account — used for support & search</div></div><span class="id-chip">#${state.user.id}</span></div>
        <div class="settings-row"><div><div class="s-label">Signed in with ${state.user.provider}</div><div class="s-sub">Manage how you access NovaCore</div></div></div>
        <div class="settings-row">
          <div><div class="s-label">Sign out</div><div class="s-sub">End your current NovaCore session</div></div>
          <button class="btn-ghost" onclick="signOut()">Sign out</button>
        </div>
      </div>
      <div class="panel">
        <h3>Preferences</h3>
        <div class="settings-row"><div><div class="s-label">Coupon alerts</div><div class="s-sub">Get notified in your Inbox when new coupons drop</div></div><div class="toggle ${state.notifPrefs.coupons?'on':''}" onclick="toggleNotifPref('coupons', this)"></div></div>
        <div class="settings-row"><div><div class="s-label">App news & updates</div><div class="s-sub">Announcements from the NovaCore team, in your Inbox</div></div><div class="toggle ${state.notifPrefs.news?'on':''}" onclick="toggleNotifPref('news', this)"></div></div>
        <div class="settings-row"><div><div class="s-label">Email receipts</div><div class="s-sub">Get a receipt after every sale</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
        <div class="settings-row"><div><div class="s-label">Show my listings publicly</div><div class="s-sub">Let anyone browse your store</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
        <div class="settings-row">
          <div><div class="s-label">Viewing NovaCore as</div><div class="s-sub">Switch between the phone and computer layout</div></div>
          <div class="device-toggle-row">
            <button class="device-toggle-btn ${state.user.device==='phone'?'active':''}" onclick="chooseDevice('phone')">📱 Phone</button>
            <button class="device-toggle-btn ${state.user.device!=='phone'?'active':''}" onclick="chooseDevice('computer')">💻 Computer</button>
          </div>
        </div>
      </div>
    </div>
    <div class="settings-grid" style="margin-top:20px;">
      <div class="panel">
        <h3><span class="nova-mark small" style="display:inline-block; vertical-align:-5px; margin-right:8px;"><svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="9" fill="url(#novaCoreGlow)"/></svg></span>Nova AI assistant</h3>
        <p style="font-size:13px; color:var(--text-muted); line-height:1.6; margin-bottom:14px;">Nova can help you price listings, negotiate offers, understand payouts, or find items — right from any page.</p>
        <button class="btn-primary" onclick="toggleAI(true)">Open Nova AI</button>
        <button class="btn-ghost" style="width:100%; justify-content:center; margin-top:10px;" onclick="openTutorialModal()">▶ Watch the quick tour</button>
      </div>
      <div class="panel">
        <h3>NovaCore support</h3>
        <p style="font-size:13px; color:var(--text-muted); line-height:1.6; margin-bottom:14px;">Have an issue with an order, payout, or your account? Reach the NovaCore team directly.</p>
        <button class="btn-primary" onclick="openSupportModal()">Contact NovaCore support</button>
      </div>
    </div>
  </div>`;
}

function openSupportModal(prefillSubject, prefillMsg){
  document.getElementById('supportModalCard').innerHTML = `
    <button class="close-x" onclick="document.getElementById('supportModalOverlay').classList.add('hidden')">&times;</button>
    <h3>Contact NovaCore support</h3>
    <p style="font-size:12.5px; color:var(--text-muted); margin-bottom:16px;">Sent to novacoreoff0@gmail.com — our team typically replies within 1–2 days. If this is about a scam, fraud, or an order that went wrong, tell us what happened — we will do the best we can to help you get your money back or your item back.</p>
    <div class="field"><label>Subject</label><input id="supSubject" placeholder="e.g. Payout hasn't arrived" value="${prefillSubject ? prefillSubject.replace(/"/g,'&quot;') : ''}"></div>
    <div class="field"><label>Message</label><textarea id="supMsg" rows="4" style="width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface-2); color:var(--text); outline:none; font-size:13.5px; resize:vertical;" placeholder="Tell us what's going on...">${prefillMsg || ''}</textarea></div>
    <button class="btn-primary" onclick="sendSupportMessage()">Send to NovaCore support</button>
  `;
  document.getElementById('supportModalOverlay').classList.remove('hidden');
}

function sendSupportMessage(){
  const subject = document.getElementById('supSubject').value.trim() || 'NovaCore support request';
  const msg = document.getElementById('supMsg').value.trim();
  if(!msg){ shakeField('supMsg'); return; }
  const body = encodeURIComponent(`${msg}\n\n— sent from NovaCore (${state.user.name}, ${state.user.email})`);
  window.open(`mailto:novacoreoff0@gmail.com?subject=${encodeURIComponent(subject)}&body=${body}`, '_blank');
  document.getElementById('supportModalOverlay').classList.add('hidden');
  showToast("Message sent — we'll do our best to help make this right, and reply within 1–2 days");
}

/* ============================================================
   ADMIN PANEL (only visible when signed in as novacoreoff0@gmail.com)
============================================================ */
const ADMIN_FILTERS = [
  { id:'all', label:'All' },
  { id:'active', label:'Active' },
  { id:'warned', label:'Warned' },
  { id:'suspended', label:'Suspended' },
  { id:'banned', label:'Banned' },
];

function computeAdminStats(){
  const s = { total: state.users.length, active:0, warned:0, suspended:0, banned:0 };
  state.users.forEach(u => { if(s[u.status] !== undefined) s[u.status]++; });
  // Real, not simulated — but this app has no server, so it can only ever see whoever is
  // actually signed in on THIS device/browser tab right now. It can't see other devices.
  s.onlineNow = state.users.filter(u => u.isOnline).length;
  return s;
}

function getFilteredUsers(){
  const q = (state.adminSearchQuery || '').trim().toLowerCase();
  const filter = state.adminStatusFilter || 'all';
  return state.users.filter(u => {
    const matchesQ = !q || String(u.id).includes(q) || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
    const matchesFilter = filter === 'all' || u.status === filter;
    return matchesQ && matchesFilter;
  });
}

function renderAdminPage(){
  const results = getFilteredUsers();
  const stats = computeAdminStats();
  return `
  <div class="page">
    <div class="page-head"><div><h2>🛠️ Developer menu</h2><p>Search NovaCore users, review account status, and moderate the platform.</p></div></div>
    <div class="stat-row">
      <div class="stat-card"><div class="label">👥 Total users</div><div class="value">${stats.total}</div><div class="delta" style="color:var(--text-muted);">Registered NovaCore accounts</div></div>
      <div class="stat-card"><div class="label">🟢 Online now</div><div class="value">${stats.onlineNow}</div><div class="delta" style="color:var(--text-muted);">Signed in on this device — no server to see other devices</div></div>
      <div class="stat-card"><div class="label">⚠️ Warned</div><div class="value">${stats.warned}</div><div class="delta" style="color:var(--amber);">Received at least one warning</div></div>
      <div class="stat-card"><div class="label">⏳ Suspended</div><div class="value">${stats.suspended}</div><div class="delta" style="color:var(--cyan);">Temporarily locked out</div></div>
      <div class="stat-card"><div class="label">⛔ Banned</div><div class="value">${stats.banned}</div><div class="delta" style="color:var(--red);">Removed from NovaCore</div></div>
    </div>
    <div class="panel announce-panel">
      <h3>📣 Send an announcement</h3>
      <p style="font-size:12.5px; color:var(--text-muted); margin-bottom:14px;">Publishes straight to every account's Inbox (if they have app news notifications on).</p>
      <div class="field"><label>Title</label><input id="annTitle" placeholder="e.g. New holiday coupons are live"></div>
      <div class="field"><label>Message</label><textarea id="annBody" rows="3" style="width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface-2); color:var(--text); outline:none; font-size:13.5px; resize:vertical;" placeholder="What do you want users to know?"></textarea></div>
      <button class="btn-primary" style="width:auto; padding:11px 22px;" onclick="publishAnnouncement()">Publish to Inbox</button>
      ${state.announcements.length ? `
      <div class="announce-log">
        ${state.announcements.slice().reverse().slice(0,4).map(a => `<div class="announce-log-row"><b>${a.title}</b><span>${timeAgo(a.at)}</span></div>`).join('')}
      </div>` : ''}
    </div>
    <div class="admin-searchbar-inline">
      <input type="text" id="adminInlineSearch" value="${state.adminSearchQuery || ''}" placeholder="Search by ID, name, or email…" oninput="filterAdminLive(this.value)">
    </div>
    <div class="admin-filter-row">
      ${ADMIN_FILTERS.map(f => `<button class="admin-filter-chip ${state.adminStatusFilter===f.id?'active':''}" onclick="setAdminFilter('${f.id}')">${f.label}</button>`).join('')}
    </div>
    <div class="admin-results" id="adminResults">
      ${results.length ? results.map(renderAdminUserCard).join('') : `<div class="empty-note">No users match this search or filter.</div>`}
    </div>
  </div>`;
}

function renderAdminUserCard(u){
  const statusClass = { active:'st-active', warned:'st-warned', suspended:'st-suspended', banned:'st-banned' }[u.status] || 'st-active';
  const statusLabel = { active:'Active', warned:'Warned', suspended:`Suspended${u.suspendDays ? ' · ' + u.suspendDays + 'd' : ''}`, banned:'Banned' }[u.status] || 'Active';
  const isDev = u.email.toLowerCase() === ADMIN_EMAIL;
  return `
  <div class="admin-card" id="admin-card-${u.id}">
    <div class="admin-card-top">
      <div class="admin-avatar">${u.name.slice(0,1).toUpperCase()}</div>
      <div class="admin-who">
        <b>${u.name} ${isDev ? '<span class="dev-badge">Developer</span>' : (u.role==='admin' ? '<span class="admin-badge">Admin</span>' : '')}</b>
        <span>${u.email} · ID #${u.id} · joined ${u.joined}${u.warnings ? ' · ' + u.warnings + ' warning' + (u.warnings>1?'s':'') : ''}${u.isOnline ? ' · <span style="color:var(--green);">● online now</span>' : ''} · ${u.device === 'phone' ? '📱 Phone' : u.device === 'computer' ? '💻 Computer' : 'device not set'}</span>
      </div>
      <span class="status-pill ${statusClass}">${statusLabel}</span>
    </div>
    <div class="admin-actions">
      <button class="btn-ghost warn-btn" onclick="warnUser(${u.id})">⚠️ Warn</button>
      <div class="suspend-inline">
        <input type="number" min="1" placeholder="Days" id="susp-${u.id}">
        <button onclick="suspendUser(${u.id})">⏳ Suspend</button>
      </div>
      <button class="btn-ghost ban-btn" onclick="banUser(${u.id})">⛔ Ban</button>
      <button class="btn-ghost kick-btn" onclick="kickUser(${u.id})">👢 Kick</button>
      ${u.status !== 'active' ? `<button class="btn-ghost reinstate-btn" onclick="reinstateUser(${u.id})">↩ Reinstate</button>` : ''}
    </div>
  </div>`;
}

function publishAnnouncement(){
  const title = document.getElementById('annTitle').value.trim();
  const body = document.getElementById('annBody').value.trim();
  if(!title || !body){ showToast('Add a title and message to publish.'); return; }
  state.announcements.push({ id: Date.now(), title, body, at: Date.now() });
  saveToStorage();
  showToast('Announcement published to every Inbox');
  showPage('admin');
  buildTabs();
}

function runAdminSearch(v){ state.adminSearchQuery = v; showPage('admin'); }

function filterAdminLive(v){
  state.adminSearchQuery = v;
  const results = getFilteredUsers();
  document.getElementById('adminResults').innerHTML = results.length ? results.map(renderAdminUserCard).join('') : `<div class="empty-note">No users match this search or filter.</div>`;
}

function setAdminFilter(filterId){
  state.adminStatusFilter = filterId;
  showPage('admin');
}

function refreshAdminResults(){
  showPage('admin'); // re-render so the stat counts and filter chips stay accurate too
}

function warnUser(id){
  const u = findUser(id); if(!u) return;
  u.warnings = (u.warnings || 0) + 1;
  if(u.status === 'active') u.status = 'warned';
  saveToStorage();
  refreshAdminResults();
  showToast(`⚠️ ${u.name} has been warned`);
}

function suspendUser(id){
  const days = Number(document.getElementById('susp-'+id).value);
  if(!days || days <= 0){ shakeField('susp-'+id); return; }
  const u = findUser(id); if(!u) return;
  u.status = 'suspended'; u.suspendDays = days; u.suspendedAt = Date.now();
  saveToStorage();
  refreshAdminResults();
  showToast(`⏳ ${u.name} suspended for ${days} day${days>1?'s':''}`);
  if(u.email.toLowerCase() === state.user.email.toLowerCase()){
    u.isOnline = false; saveToStorage();
    setTimeout(()=>forceExitToStatusScreen(u), 700);
  }
}

function banUser(id){
  const u = findUser(id); if(!u) return;
  u.status = 'banned';
  saveToStorage();
  refreshAdminResults();
  showToast(`⛔ ${u.name} has been banned`);
  if(u.email.toLowerCase() === state.user.email.toLowerCase()){
    u.isOnline = false; saveToStorage();
    setTimeout(()=>forceExitToStatusScreen(u), 700);
  }
}

function kickUser(id){
  const u = findUser(id); if(!u) return;
  refreshAdminResults();
  showToast(`👢 ${u.name} was kicked from their session`);
  if(u.email.toLowerCase() === state.user.email.toLowerCase()) setTimeout(signOut, 400);
}

function reinstateUser(id){
  const u = findUser(id); if(!u) return;
  u.status = 'active'; u.suspendDays = null; u.suspendedAt = null; u.warnings = 0;
  saveToStorage();
  refreshAdminResults();
  showToast(`↩ ${u.name} has been reinstated to active`);
}

/* ============================================================
   AVATAR MENU / TOAST
============================================================ */
function toggleAvatarMenu(){ document.getElementById('avatarDropdown').classList.toggle('hidden'); }
document.addEventListener('click', (e)=>{ if(!e.target.closest('.avatar-menu')) document.getElementById('avatarDropdown')?.classList.add('hidden'); });

function showToast(text){
  const t = document.getElementById('toast');
  document.getElementById('toastText').textContent = text;
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(()=>t.classList.remove('show'), 3200);
}

/* ============================================================
   NOVA AI — tries a live Claude call, and always has a useful
   local fallback so Nova never just dead-ends with an error.
   (See the code comment further down for why the live call can fail.)
============================================================ */
/* ============================================================
   NOVA QUICK TOUR — an interactive step-through walkthrough with
   video-player-style controls (progress bar, play/pause). It is
   NOT a recorded video file — there's no way to generate one here —
   so it's labeled plainly as an interactive walkthrough.
============================================================ */
const TUTORIAL_STEPS = [
  { icon:'🛍️', title:'Browse & buy', body:"Explore listings by category from the top nav, or check Home for fresh finds. Tap Buy now for an instant purchase, or Make an offer to negotiate." },
  { icon:'📦', title:'List an item', body:'Hit "+ List an item" anywhere. Add a title, model/SKU, price, condition, and a photo — it publishes straight to that category.' },
  { icon:'💳', title:'Fees & payouts', body:"NovaCore takes a small fee per sale — 8% on Basic, down to 3% on Business. Connect a payout method under Payments to cash out." },
  { icon:'💬', title:'Message & ask Nova', body:'Message a seller directly about an item from Messages, or open Nova AI anytime for pricing help or a fair-offer suggestion.' },
  { icon:'🛡️', title:'Stay safe', body:"Keep payments on NovaCore, and if anything goes wrong, contact support from Settings — we'll do our best to help make it right." },
];

let tutorialStep = 0;
let tutorialPlaying = false;
let tutorialTimer = null;

function openTutorialModal(){
  tutorialStep = 0;
  tutorialPlaying = false;
  clearInterval(tutorialTimer);
  renderTutorialStep();
  document.getElementById('tutorialModalOverlay').classList.remove('hidden');
}

function closeTutorial(){
  clearInterval(tutorialTimer);
  tutorialPlaying = false;
  document.getElementById('tutorialModalOverlay').classList.add('hidden');
}

function renderTutorialStep(){
  const s = TUTORIAL_STEPS[tutorialStep];
  const pct = Math.round(((tutorialStep+1) / TUTORIAL_STEPS.length) * 100);
  document.getElementById('tutorialModalCard').innerHTML = `
    <button class="close-x" onclick="closeTutorial()">&times;</button>
    <div class="tutorial-eyebrow">NOVACORE QUICK TOUR · interactive walkthrough</div>
    <div class="tutorial-stage">
      <div class="tutorial-ic">${s.icon}</div>
      <h3>${s.title}</h3>
      <p>${s.body}</p>
    </div>
    <div class="tutorial-progress"><div class="tutorial-progress-fill" style="width:${pct}%"></div></div>
    <div class="tutorial-controls">
      <button class="btn-ghost" onclick="tutorialPrev()" ${tutorialStep===0 ? 'disabled' : ''}>◀ Back</button>
      <button class="tutorial-play-btn" onclick="toggleTutorialPlay()" title="${tutorialPlaying ? 'Pause' : 'Play'}">${tutorialPlaying ? '⏸' : '▶'}</button>
      <button class="btn-ghost" onclick="tutorialNext()">${tutorialStep === TUTORIAL_STEPS.length-1 ? 'Done' : 'Next ▶'}</button>
    </div>
    <div class="tutorial-dots">${TUTORIAL_STEPS.map((_,i)=>`<span class="tutorial-dot ${i===tutorialStep?'active':''}"></span>`).join('')}</div>
  `;
}

function tutorialNext(){
  if(tutorialStep < TUTORIAL_STEPS.length - 1){ tutorialStep++; renderTutorialStep(); }
  else closeTutorial();
}
function tutorialPrev(){
  if(tutorialStep > 0){ tutorialStep--; renderTutorialStep(); }
}
function toggleTutorialPlay(){
  tutorialPlaying = !tutorialPlaying;
  clearInterval(tutorialTimer);
  if(tutorialPlaying){
    tutorialTimer = setInterval(()=>{
      if(tutorialStep < TUTORIAL_STEPS.length - 1){ tutorialStep++; renderTutorialStep(); }
      else { tutorialPlaying = false; clearInterval(tutorialTimer); renderTutorialStep(); }
    }, 4000);
  }
  renderTutorialStep();
}

let aiHistory = [];

function toggleAI(open){ document.getElementById('aiPanel').classList.toggle('open', open); }

function seedAIWelcome(){
  const box = document.getElementById('aiMessages');
  box.innerHTML = '';
  addAIBubble('assistant', `Hey ${state.user.name.split(' ')[0] || 'there'}! I'm Nova, your NovaCore shopping assistant. I can help you price a listing, decide on an offer, understand payouts and fees, or just find something good to buy. What's on your mind?`);
}

function addAIBubble(role, text, opts){
  opts = opts || {};
  const box = document.getElementById('aiMessages');
  const time = new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
  const row = document.createElement('div');
  row.className = 'msg-row ' + role;
  row.innerHTML = `
    ${role === 'assistant' ? '<div class="msg-avatar bot"><div class="nova-mark"><svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="9" fill="url(#novaCoreGlow)"/></svg></div></div>' : ''}
    <div class="msg-col">
      <div class="msg ${role}"><span class="msg-text"></span></div>
      <div class="msg-time">${time}</div>
    </div>
    ${role === 'user' ? `<div class="msg-avatar user">${(state.user.initials || 'U')}</div>` : ''}
  `;
  box.appendChild(row);
  box.scrollTop = box.scrollHeight;
  const textEl = row.querySelector('.msg-text');
  if(role === 'assistant' && !opts.instant){
    typewriterText(textEl, text, box);
  } else {
    textEl.textContent = text;
  }
  return row;
}

function typewriterText(el, text, scrollBox){
  let i = 0;
  const speed = text.length > 240 ? 4 : 13;
  (function step(){
    el.textContent = text.slice(0, i);
    if(scrollBox) scrollBox.scrollTop = scrollBox.scrollHeight;
    i++;
    if(i <= text.length) setTimeout(step, speed);
  })();
}

function sendQuickPrompt(text){
  toggleAI(true);
  document.getElementById('aiInputBox').value = text;
  sendAIMessage();
}

// A small rule-based Nova that always has something useful to say, grounded in the
// app's real state (current plan, fee rates, listings). Used whenever the live API
// call isn't reachable — see note in sendAIMessage().
function generateLocalNovaReply(text){
  const t = text.toLowerCase();
  const feePct = Math.round((FEE_RATES[state.currentPlan] ?? FEE_RATES.basic) * 100);

  // scam / fraud / order-gone-wrong reports — handle this before anything else
  if(t.includes('scam') || t.includes('fraud') || t.includes('ripped off') || t.includes('rip off') || t.includes('stolen') || t.includes('never showed up') || t.includes('never arrived') || t.includes("didn't get") || t.includes('did not get') || t.includes("didn't receive") || t.includes('did not receive') || t.includes('not receive') || t.includes('never received') || t.includes('never paid') || t.includes("wasn't paid") || t.includes('was not paid')){
    return `I'm sorry that happened. Go to Settings → Contact NovaCore support and give us your order details — the item, the other person involved, and what happened. We will do the best we can to help you get your money back or your item back. We can't promise every case can be fully resolved, but we'll work hard on it.`;
  }

  // pricing / fair offer questions, optionally about a specific listing
  const mentioned = LISTINGS.find(i => t.includes(i.title.toLowerCase().split(' ')[0].toLowerCase()) && t.includes(i.title.toLowerCase().split(' ').slice(-1)[0]));
  if(t.includes('offer') || t.includes('fair') || t.includes('negotiat') || t.includes('counter')){
    if(mentioned){
      const low = Math.round(mentioned.price * 0.85);
      const high = Math.round(mentioned.price * 0.93);
      return `For the ${mentioned.title} (listed at $${mentioned.price.toLocaleString()}, condition: ${mentioned.cond}), a reasonable opening offer is usually $${low.toLocaleString()}–$${high.toLocaleString()} — enough of a discount to be worth the seller's time, but not so low it reads as a lowball. Mention the model number and condition in your message, and be ready to meet closer to asking if they counter.`;
    }
    return `For any listing, a fair opening offer is typically 7–15% below the asking price — closer to 15% if the condition listing is "Good" or "Fair," closer to 7% for "Like New" or "New." Reference the model/SKU in your message so the seller knows you've actually looked at the details, and expect one round of back-and-forth before landing somewhere in the middle.`;
  }

  // fees / payouts / plans
  if(t.includes('fee') || t.includes('payout') || t.includes('plan') || t.includes('earn')){
    return `You're currently on the ${state.currentPlan[0].toUpperCase()+state.currentPlan.slice(1)} plan, so NovaCore takes a ${feePct}% fee on each sale — sell something for $100 and you'd keep $${(100*(1-feePct/100)).toFixed(2)}. Basic is $0/mo at 8%, Pro is $9.99/mo at 5% with 1–2 day payouts, and Business is $29.99/mo at 3% with instant payouts. Payouts go to whichever method you've connected under Payments — Apple Pay, Cash App, card, or bank.`;
  }

  // listing description help
  if(t.includes('listing') || t.includes('description') || t.includes('write') || t.includes('sneaker') || t.includes('sell my')){
    return `A good listing description covers four things fast: exact item name + model/SKU, condition and any flaws (be specific — buyers trust honesty), what's included (box, cables, accessories), and why you're selling. For example: "Nike Air Max 97, size 11, deadstock — never worn, tags still attached. Selling because I ordered the wrong size." Want me to draft one for a specific item? Tell me the item, size/model, and condition.`;
  }

  // finding items / browsing
  if(t.includes('find') || t.includes('recommend') || t.includes('looking for') || t.includes('buy')){
    return `Tell me a category or budget and I can point you in the right direction — right now NovaCore has listings across Games, Shoes, Clothing, Jewelry, and Electronics, ranging from a $65 Game Boy Color to a $4,200 vintage Rolex Datejust. What are you in the market for?`;
  }

  // greeting / smalltalk
  if(t.includes('hi') || t.includes('hello') || t.includes('hey')){
    return `Hey! I can help you price a listing, evaluate an offer, understand fees and payouts, or write a listing description. What do you want to tackle first?`;
  }

  return `I can help with pricing a listing, deciding on a fair offer, understanding NovaCore's fees and payouts, or writing a listing description — try asking about one of those, or tell me the specific item you're buying or selling and I'll dig in.`;
}

async function sendAIMessage(){
  const input = document.getElementById('aiInputBox');
  const text = input.value.trim();
  if(!text) return;
  input.value = '';
  addAIBubble('user', text, { instant:true });
  aiHistory.push({ role:'user', content:text });

  const box = document.getElementById('aiMessages');
  const typing = document.createElement('div');
  typing.className = 'msg assistant typing';
  typing.innerHTML = '<span class="think-label">Nova is thinking</span><div class="dot"></div><div class="dot"></div><div class="dot"></div>';
  box.appendChild(typing);
  box.scrollTop = box.scrollHeight;

  // NOTE ON WHY THIS SOMETIMES CAN'T REACH THE LIVE MODEL:
  // The direct fetch() to api.anthropic.com below only succeeds when this page is running
  // inside Claude.ai's own Artifact preview, which transparently proxies the request and
  // injects credentials. Once these files are downloaded and hosted anywhere else (your
  // own server, GitHub Pages, opened as a local file, etc.), the browser has no API key
  // and the request will fail — that's expected, not a bug in this file, and it's why the
  // response always fell through to a generic error before. To get real live Claude
  // replies outside of Claude.ai, you'd need a small backend of your own that holds the
  // API key and forwards chat requests — this file can't safely embed a real key itself.
  // Either way, sendAIMessage() below now always gives a genuinely useful answer via
  // generateLocalNovaReply() whenever the live call isn't available, so Nova never just
  // dead-ends with "I'm having trouble connecting."
  let replyText = null;
  try{
    const systemPrompt = `You are Nova, the built-in AI shopping assistant for NovaCore, an online marketplace where people buy and sell items like games, shoes, clothing, jewelry, and electronics. You help users: price their listings fairly, decide on fair counter-offers, understand seller fees/payouts/plans (Basic $0/mo 8% fee, Pro $9.99/mo 5% fee, Business $29.99/mo 3% fee), write good listing descriptions, and navigate buying/selling safely. If a user says they've been scammed, ripped off, or an order went wrong (never received an item, never got paid, etc.), respond with empathy, tell them to go to Settings → Contact NovaCore support with their order details, and say NovaCore will do the best it can to help them get their money back or their item back — while being honest that this can't be guaranteed in every case. Be warm, sharp, and concise — a few short sentences or a tight list, not an essay. Never invent fake order numbers or make promises about real money movement.`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({
        model:"claude-sonnet-4-6",
        max_tokens:1000,
        system: systemPrompt,
        messages: aiHistory
      })
    });

    if(response.ok){
      const data = await response.json();
      if(data && data.content){
        const parsed = data.content.filter(b=>b.type==='text').map(b=>b.text).join('\n').trim();
        if(parsed) replyText = parsed;
      }
    }
  }catch(err){
    // network/CORS/auth failure — expected outside the Claude.ai artifact preview, fall through to local reply
  }

  if(!replyText) replyText = generateLocalNovaReply(text);

  typing.remove();
  addAIBubble('assistant', replyText);
  aiHistory.push({ role:'assistant', content:replyText });
}

document.addEventListener('keydown', (e)=>{
  if(e.key !== 'Escape') return;
  ['itemModalOverlay','listModalOverlay','supportModalOverlay','tutorialModalOverlay','chooserOverlay'].forEach(id=>{
    const el = document.getElementById(id);
    if(el && !el.classList.contains('hidden')) el.classList.add('hidden');
  });
  const dropdown = document.getElementById('avatarDropdown');
  if(dropdown) dropdown.classList.add('hidden');
  if(document.getElementById('aiPanel').classList.contains('open')) toggleAI(false);
});

// Restore anything saved from a previous visit to this browser (listings, accounts,
// moderation status, messages, announcements). Runs once the whole file has loaded.
loadFromStorage();